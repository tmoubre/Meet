//NumberOfEvents.jsx  

import React from 'react';

const NumberOfEvents = ({ currentNOE, setCurrentNOE }) => {
  const handleInputChanged = (e) => {
    const value = e.target.value;
    const parsed = parseInt(value, 10);
    // If user clears the input, parsed will be NaN → we set 0
    setCurrentNOE(isNaN(parsed) ? 0 : parsed);
  };

  return (
    <div className="number-of-events">
      <label htmlFor="number-of-events">Number of Events:</label>
      <input
        id="number-of-events"
        type="number"
        role="spinbutton"
        aria-label="Number of Events:"
        value={currentNOE}
        onChange={handleInputChanged}
      />
    </div>
  );
};

export default NumberOfEvents;



